<template>
  <div class="sync-container">
    <div class="sync-header">
      <div class="device-info">
        <span class="device-label">设备名称:</span>
        <h3>{{ device_name }}</h3>
      </div>
      <div class="tab-buttons">
        <button
          @click="activeTab = 'clipboard'"
          :class="['tab-btn', { active: activeTab === 'clipboard' }]"
        >
          剪切板同步
        </button>
        <button
          @click="activeTab = 'file'"
          :class="['tab-btn', { active: activeTab === 'file' }]"
        >
          文件传输
        </button>
      </div>
      <button @click="$emit('close')" class="close-btn">×</button>
    </div>

    <div class="sync-content">
      <!-- 剪切板同步组件 -->
      <ClipboardPanel
        v-if="activeTab === 'clipboard'"
        :device_name="device_name"
        :device_ip="device_ip"
        :device_port="device_port"
      />

      <!-- 文件传输组件 -->
      <FileTransferPanel
        v-else
        :device_name="device_name"
        :device_ip="device_ip"
        :device_port="device_port"
      />
    </div>
  </div>
</template>

<script>
import ClipboardPanel from "./sync/ClipboardPanel.vue";
import FileTransferPanel from "./sync/FileTransferPanel.vue";

export default {
  components: {
    ClipboardPanel,
    FileTransferPanel,
  },
  props: {
    device_name: String,
    device_ip: String,
    device_port: String,
  },
  data() {
    return {
      activeTab: "clipboard",
    };
  },
};
</script>

<style scoped>
.sync-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 10px;
  border-bottom: 1px solid #eee;
}

.device-info {
  display: flex;
  align-items: center;
  gap: 8px;
}

.device-label {
  color: #666;
  font-size: 14px;
}

.tab-buttons {
  display: flex;
  gap: 10px;
}

.tab-btn {
  padding: 8px 16px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  background: #f0f0f0;
  transition: all 0.3s ease;
}

.tab-btn.active {
  background: #4caf50;
  color: white;
}

.close-btn {
  background: none;
  border: none;
  font-size: 24px;
  cursor: pointer;
  color: #666;
}

.sync-content {
  min-height: 300px;
}
</style> 