<template>
  <div class="tab">internet</div>
</template>