<template>
  <div class="clipboard-panel">
    <div class="clipboard-area">
      <textarea
        v-model="clipboardContent"
        @input="handleInput"
        placeholder="在此输入或粘贴内容..."
      ></textarea>
    </div>
    <div class="sync-status">
      {{ syncStatus }}
    </div>
  </div>
</template>

<script>
export default {

};
</script>

<style scoped>
.clipboard-panel {
  padding: 10px;
}

.clipboard-area textarea {
  width: 100%;
  height: 200px;
  padding: 10px;
  border: 1px solid #ddd;
  border-radius: 4px;
  resize: none;
}

.sync-status {
  margin-top: 10px;
  color: #666;
  font-size: 14px;
}
</style> 