<script>
import ErrorSlot from "./../views/ErrorSlot.vue";
import io from "socket.io-client"; // 导入 socket.io-client
import localconnector from "./LocalConnector.vue";
import lk from "./LinkFrame.vue";
import syncpanel from "./toSync.vue";
export default {
  components: {
    ErrorSlot,
    localconnector,
    lk,
    syncpanel
  },

  data() {
    return {
      localIPs: [], // 用于存储扫描到的局域网 IP 地址
      error: "", // 用于存储错误信息
      selectedIP: "", // 存储用户选择的 IP 地址
      isListening: false, // 用于标记是否正在监听局域网服务
      inputError: false, // 用于标记输入框是否出错
      isServiceOpen: false,
      socket: null, // 用于存储 WebSocket 连接实例
      socketefws: null, // 存储efws实例
      online_dev: "", // 所有在线的设备
      linkPort: 33451, //连接端口
      isdevconnected: false, //记录连接设备列表是否有设备
      connecteddev: [],
    };
  },

  // 在组件挂载时自动触发获取 IP 地址
  async mounted() {
    await this.scanLocalIPs();
  },

  methods: {
    validateIP() {
      if (this.selectedIP.trim() === "" || this.inputError) {
        // 如果输入框为空，设置错误状态
        this.inputError = true;
        return;
      } else {
        this.inputError = false; // 输入框非空，清除错误状态
      }
    },
    validatePort() {
      var re = /^[A-Za-z]+$/; //
      var re_hanzi = /^[\u4e00-\u9fa5]*$/;
      //验证端口
      // 允许的端口范围是 0 到 65535
      const portNumber = Number(this.linkPort);
      // 限制输入为数字且不允许超出范围
      if (
        String(this.linkPort).match(re) ||
        String(this.linkPort).match(re_hanzi)
      ) {
        this.linkPort = "";
      }
      if (this.linkPort && (portNumber < 0 || portNumber > 65535)) {
        this.linkPort = this.linkPort.slice(0, -1); // 移除最后一个输入的字符
      }
    },
    // 扫描本机所有内网IP
    async scanLocalIPs() {
      this.localIPs = []; // 清空 IP 数组
      this.error = ""; // 清空错误信息

      try {
        const response = await fetch("http://127.0.0.1:5001/api/getlocalip");
        const data = await response.json();

        if (data.localIPs && data.localIPs.length > 0) {
          this.localIPs = data.localIPs; // 设置扫描到的 IP 地址
        } else {
          this.error = "未发现 IP 地址"; // 如果没有扫描到 IP 地址
        }
      } catch (err) {
        console.error("Error scanning local IPs:", err);
        this.error = "获取局域网 IP 失败，请检查网络连接或重试。"; // 请求失败时显示的错误信息
      }
    },

    // 切换监听状态
    async toggleListening() {
      this.listen_action = this.isListening ? "0" : "1";

      try {
        const response = await fetch(
          `http://127.0.0.1:5001/api/listenserver?ls=${this.listen_action}` //调用监听接口
        );
        const data = await response.json();
        if (data.status == "1" && !this.isListening) {
          this.isListening = true;
          this.online_dev = "";
          this.setupWebSocket();
        } else if (data.status == "2" && this.isListening) {
          this.isListening = false;
          this.closeWebSocket();
        }
      } catch (err) {
        this.buttonText = "监听局域网服务";
        this.error = "查找错误"; // 请求失败时显示的错误信息
      }
    },

    // 连接到选择的 IP 地址
    async serverOpen() {
      this.action = this.isServiceOpen ? "0" : "1";

      try {
        const response = await fetch(
          `http://127.0.0.1:5001/api/serv?ip=${this.selectedIP}&port=${this.linkPort}&isopen=${this.action}`
        ); //监听发布者服务打开/关闭

        const data = await response.json();

        if (data.status_id === 1) {
          this.isServiceOpen = true;
          this.setupEFws();
        } else if (data.status_id === 2) {
          this.isServiceOpen = false;
        } else {
          this.buttonText = "服务开启失败";
        }
      } catch (err) {
        this.buttonText = "开放服务";
        this.error = "获取局域网 IP 失败，请检查网络连接或重试。"; // 请求失败时显示的错误信息
      }
    },

    setupEFws() {
      this.socketefws = new WebSocket("ws://127.0.0.1:33456?userId=frontws");

      // Connection opened
      this.socketefws.onopen = () => {
        console.log("Connected to backend WebSocket");
      };

      // Listen for messages
      this.socketefws.onmessage = (event) => {
        const fromlocaldevdata = event.data.toString();
        // 解析外层的 JSON
        const outerData = JSON.parse(fromlocaldevdata);
        // 解析内层的 JSON 字符串
        const deviceData = JSON.parse(outerData.fromlocaldev);
        console.log(deviceData);
        if (deviceData.status == "accept") {
          this.addDevicelist(
            deviceData.localreqlinknames,
            deviceData.localreqlinkip,
            deviceData.localreqlinkport
          );
        } else if (deviceData.status == "reject") {
          // 重写remove
          this.connecteddev.forEach((device) => {
            if (device.id === deviceData.localreqlinknames) {
              device.status_dev = false;
              device.opensyncpanel = false;
            }
          });
          if (this.connecteddev.every((device) => !device.status_dev)) {
            this.isdevconnected = false;
          }
        }
      };
      this.socketefws.on("disconnect", () => {
        console.log("Disconnected from WebSocket");
      });
      console.log(this.connecteddev);
    }, // 建立node EFws

    setupWebSocket() {
      this.socket = io("http://localhost:5001"); //建立与flask ws的连接
      this.socket.on("connect", () => {
        console.log("Connected to WebSocket");
      }); //连接log下
      // 监听更新
      this.socket.on("device_list", (data) => {
        if (data && data.online_device) {
          console.log(data.online_device);
          this.online_dev = data.online_device;
        }
      });
      // 监听 WebSocket 错误
      this.socket.on("error", (error) => {
        console.error("WebSocket error:", error);
      });

      // 监听 WebSocket 断开连接
      this.socket.on("disconnect", () => {
        console.log("Disconnected from WebSocket");
      });
    },

    // 关闭 WebSocket 连接
    closeWebSocket() {
      if (this.socket) {
        this.socket.disconnect();
        console.log("WebSocket disconnected");
      }
    },

    // 在组件销毁时关闭 WebSocket 连接
    beforeDestroy() {
      this.closeWebSocket();
    },
    //连接设备
    async connectToDevice(device_name, ip, port) {
      const res = await fetch(
        `http://127.0.0.1:3345/tolocalws?device_ip=${ip}&device_port=${port}&connect_status=open` //主动连接
      );
      const resDataOpen = await res.json();
      if (resDataOpen.LinkStatus == "connectok") {
        this.addDevicelist(device_name, ip, port);
      }
    },

    addDevicelist(device_name, device_ip, device_port) {
      this.isdevconnected = true;
      if (this.connecteddev.length == 0 && this.isdevconnected) {
        this.connecteddev.push({
          id: device_name,
          ip: device_ip,
          port: device_port,
          status_dev: true,
          opensyncpanel: false
        });
      } else {
        const existingDevice = this.connecteddev.find(
          (device) => device.id === device_name
        );

        if (existingDevice) {
          // 如果设备已经在列表中，更新其状态
          existingDevice.status_dev = true;
        } else {
          // 如果设备不在列表中，添加新设备
          this.connecteddev.push({
            id: device_name,
            ip: device_ip,
            port: device_port,
            status_dev: true,
            opensyncpanel: false
          });
        }
      }
      console.log(this.connecteddev);
    },
    removeDevice(index) {
      if (this.connecteddev[index]) {
        this.connecteddev[index].status_dev = false;
        this.connecteddev[index].opensyncpanel = false;
        // 检查是否所有设备都已断开连接
        if (this.connecteddev.every((device) => !device.status_dev)) {
          this.isdevconnected = false;
        }
      }
    },
    openDeviceSync(index) {
      if (this.connecteddev[index]) {
          this.connecteddev[index].opensyncpanel = true;
      }
    },
  },
};
</script>


<template>
  <div class="layout-container">
    <div v-if="isdevconnected && isServiceOpen" class="connected-device-container">
      <div class="panel-header">
        <span>已连接设备</span>
      </div>

      <TransitionGroup name="switch-fade" tag="ul" class="device-list">
        <div v-for="(device, index) in connecteddev" :key="device.id">
          <div v-if="device.status_dev" class="device-item-wrapper">
            <localconnector
              :device_name="device.id"
              :device_ip="device.ip"
              :device_port="device.port"
              :index="index"
              @close-device="removeDevice"
              @open-device="openDeviceSync"
            />
          </div>
          <div v-if="device.opensyncpanel" class="sync-panel">
            <syncpanel
              :device_name="device.id"
              :device_ip="device.ip"
              :device_port="device.port"
            />
          </div>
        </div>
      </TransitionGroup>
    </div>

    <div class="control-panel">
      <div v-if="localIPs.length > 0" class="local-ip-section">
        <div class="ip-list-container">
          <h3 class="section-title">本地IP地址</h3>
          <div class="ip-list">
            <div v-for="(ip, index) in localIPs" :key="index" class="ip-item">
              {{ ip }}
            </div>
          </div>
        </div>

        <div class="control-section">
          <div class="input-group">
            <input
              v-model="selectedIP"
              @input="validateIP"
              placeholder="选择要开放的IP"
              :class="{ 'input-error': inputError }"
              class="ip-input"
            />
            <input
              v-model="linkPort"
              placeholder="端口号"
              @input="validatePort"
              :class="{ 'input-error': inputError }"
              class="port-input"
            />
          </div>

          <div class="button-group">
            <button
              @click="serverOpen"
              :class="['primary-button', isServiceOpen ? 'active' : '']"
            >
              {{ isServiceOpen ? "服务运行中 (点击关闭)" : "开启服务" }}
            </button>
          </div>

          <div v-if="inputError" class="error-message">
            未输入IP地址或端口格式错误
          </div>
        </div>

        <lk v-if="isServiceOpen" @lksuccess="addDevicelist" class="link-component" />

        <div v-if="isServiceOpen" class="listener-section">
          <button
            @click="toggleListening"
            :class="['primary-button', isListening ? 'active' : '']"
          >
            {{ isListening ? "停止监听" : "监听局域网" }}
          </button>

          <div v-if="isListening" class="online-devices">
            <div v-if="online_dev.length > 0" class="device-grid">
              <div
                v-for="(device, index) in online_dev"
                :key="index"
                class="device-card"
              >
                <div class="device-card-content">
                  <div :class="['signal-indicator', device.device_name ? 'online' : 'offline']" />
                  <span class="device-name">{{ device.device_name }}</span>
                  <button
                    @click="connectToDevice(device.device_name, device.device_ip, device.device_nodeport)"
                    class="connect-btn"
                  >
                    连接
                  </button>
                </div>
              </div>
            </div>
            <div v-else class="no-devices">暂无在线设备</div>
          </div>
        </div>
      </div>

      <div v-else class="error-section">
        <ErrorSlot>未发现IP，请检查服务是否开启</ErrorSlot>
        <button @click="scanLocalIPs" class="primary-button">重新扫描</button>
      </div>
    </div>
  </div>
</template>

<style scoped>
.layout-container {
  display: flex;
  gap: 24px;
  padding: 20px;
  height: 100vh;
  background: #f5f7fa;
}

.connected-device-container {
  flex: 0 0 300px;
  background: white;
  border-radius: 12px;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.08);
  padding: 20px;
  height: fit-content;
}

.control-panel {
  flex: 1;
  background: white;
  border-radius: 12px;
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.08);
  padding: 24px;
}

.panel-header {
  margin-bottom: 20px;
  padding-bottom: 12px;
  border-bottom: 1px solid #eee;
}

.panel-header span {
  font-size: 16px;
  color: #333;
  font-weight: 500;
}

.section-title {
  font-size: 18px;
  color: #2c3e50;
  margin-bottom: 16px;
}

.ip-list-container {
  margin-bottom: 24px;
}

.ip-list {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}

.ip-item {
  background: #f1f5f9;
  padding: 8px 16px;
  border-radius: 6px;
  font-size: 14px;
  color: #64748b;
}

.input-group {
  display: flex;
  gap: 12px;
  margin-bottom: 16px;
}

.ip-input, .port-input {
  padding: 10px 16px;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  font-size: 14px;
  transition: all 0.3s ease;
}

.ip-input {
  flex: 1;
}

.port-input {
  width: 100px;
}

.input-error {
  border-color: #ef4444;
}

.primary-button {
  padding: 10px 24px;
  border: none;
  border-radius: 8px;
  background: #3b82f6;
  color: white;
  font-size: 14px;
  cursor: pointer;
  transition: all 0.3s ease;
}

.primary-button:hover {
  background: #2563eb;
  transform: translateY(-1px);
}

.primary-button.active {
  background: #16a34a;
}

.device-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
  gap: 16px;
  margin-top: 20px;
}

.device-card {
  background: #f8fafc;
  border-radius: 8px;
  padding: 16px;
  transition: all 0.3s ease;
}

.device-card:hover {
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
}

.device-card-content {
  display: flex;
  align-items: center;
  gap: 12px;
}

.signal-indicator {
  width: 8px;
  height: 8px;
  border-radius: 50%;
}

.signal-indicator.online {
  background: #22c55e;
  box-shadow: 0 0 0 4px rgba(34, 197, 94, 0.2);
}

.signal-indicator.offline {
  background: #94a3b8;
}

.connect-btn {
  margin-left: auto;
  padding: 6px 12px;
  border: none;
  border-radius: 6px;
  background: #3b82f6;
  color: white;
  font-size: 12px;
  cursor: pointer;
  transition: all 0.2s ease;
}

.connect-btn:hover {
  background: #2563eb;
}

.sync-panel {
  position: fixed;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  z-index: 1000;
  background: white;
  border-radius: 12px;
  box-shadow: 0 4px 24px rgba(0, 0, 0, 0.15);
}

.error-message {
  color: #ef4444;
  font-size: 12px;
  margin-top: 8px;
}

/* 动画效果 */
.switch-fade-enter-active,
.switch-fade-leave-active {
  transition: all 0.3s ease;
}

.switch-fade-enter-from,
.switch-fade-leave-to {
  opacity: 0;
  transform: translateY(10px);
}

@keyframes pulse {
  0% {
    transform: scale(1);
    opacity: 0.8;
  }
  50% {
    transform: scale(1.1);
    opacity: 1;
  }
  100% {
    transform: scale(1);
    opacity: 0.8;
  }
}
</style>
