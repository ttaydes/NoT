<script>
export default {
  props: ["title", "content"],

  emits: ["enlarge-text"],
};
</script>

<template>
  <h2>{{ title }}</h2>
  <p>{{ content }}</p>
  <button @click="$emit('enlarge-text')">large</button>
  <button @click="$emit('ensmall-text')">small</button>
</template>